<?php
namespace app\index\controller;

class Message extends Common
{
    //信息
    public function index()
    {

        return view('index',[

        ]);
    }

}