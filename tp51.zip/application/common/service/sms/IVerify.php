<?php
namespace app\common\service\sms;

interface IVerify
{
    function getContent($verify);
}