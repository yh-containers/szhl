<?php
namespace app\common\service\wechat;

class Config
{
    //应用id
    const APPID = 'wxc3fba19272fcc5bf';
    //
    const APPSECRET = '8d794bfa3defdc4ed813344cca787d68';
}