<?php
namespace app\common\model;



class ProductLogs extends Base
{
    protected $name='product_logs';


}