<?php
namespace app\common\model;

class UserMoneyLogs extends Base
{
    protected $name='user_money_logs';

    protected $json = ['extra'];
}