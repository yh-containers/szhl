<?php
namespace app\common\model;



class ProductReqLogs extends Base
{
    protected $name='product_req_logs';


}