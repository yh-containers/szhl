<?php
namespace app\common\model;

class UserBankCard extends Base
{
    protected $name='user_bank_card';

}